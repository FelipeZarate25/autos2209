/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package holamundo;

import poo.conceptos.basicos.Automovil;

/**
 *
 * @author felipezarate
 */
public class HolaMundo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola Mundo Java !!!!");

        //per1 es un ejemplar(instancia) #INDENTIDAD nombre/variable
        Persona per1 = new Persona();
        per1.setNombre("Felipe JPZ ");
        System.out.println("Nombre: " + per1.getNombre());
        per1.comer("hamburguesa hawiana!!!");

        Persona per2 = new Persona();
        per2.setNombre("Felipe ");
        System.out.println("Nombre per 2: " + per2.getNombre());
        per2.comer("pizza hawaiana! ");

        
        Automovil bocho = new Automovil();
        bocho.setMarca("VW ");
        System.out.println("Marca: "+ bocho.getMarca());
        
        
    }

}
